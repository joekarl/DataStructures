#import "RObject.h"

@interface CollisionKey : RObject

@end
