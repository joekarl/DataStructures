#import "CollisionKey.h"

@implementation CollisionKey

-(long)hash
{
  //this will be a collision :)
  return 5;
}

@end
