#!/bin/bash

javac JSMain.java
