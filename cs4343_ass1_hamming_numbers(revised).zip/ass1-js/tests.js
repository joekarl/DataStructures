load('spec/linkedListSpec.js');
load('spec/hammingNumbersSpec.js');
