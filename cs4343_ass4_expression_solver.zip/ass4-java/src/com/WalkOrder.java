package com;

/*
 * enum spicifying different walk orders
 */
public enum WalkOrder {
  INORDER,
  PREORDER,
  POSTORDER
}



